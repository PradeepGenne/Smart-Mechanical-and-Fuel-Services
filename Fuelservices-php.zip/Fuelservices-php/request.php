<?php
$host = "localhost";
$user = "u711879936_sss";
$pass = "android";
$dbname = "u711879936_sss";

$con = mysqli_connect($host, $user, $pass,$dbname);  

if(!$con){  
  die('Could not connect: '.mysqli_connect_error());  
}else{
  
    
    function data($query) {
        
    $user=array();
   if(mysqli_num_rows($query)>0){
    while($row=mysqli_fetch_assoc($query)){
	            $user[] = $row;
                }
      echo json_encode(array("error"=>"false","message"=>"Success","user"=>$user));
     }else{
      echo json_encode(array("error"=>"false","message"=>"No data","user"=>$user));
  }  
    }
    
      $id=$_POST['id'];
    $wemail=$_POST['wemail'];
    $wname=$_POST['wname'];
    $wnum=$_POST['wnum'];
    $wtype=$_POST['wtype'];
    $uname=$_POST['uname'];
    $unum=$_POST['unum'];
    $uemail=$_POST['uemail'];
    $service=$_POST['service'];
    $addinfo=$_POST['addinfo'];
    $status=$_POST['status'];
    $cost=$_POST['cost'];
    $rating=$_POST['rating'];
    $feedback=$_POST['feedback'];
    $loc=$_POST['loc'];
      $condition=$_POST['condition'];
      
      
if($condition=="addrequest"){

 
     $insertQuery="INSERT INTO smartservice_services (wemail,wname, wnum, wtype, uname, unum, uemail, service, addinfo, status,cost,rating, feedback,loc) VALUE('$wemail',
   '$wname','$wnum', '$wtype','$uname','$unum','$uemail','$service','$addinfo','$status','$cost','$rating','$feedback','$loc')";
  $result=mysqli_query($con,$insertQuery);
  if($result){
   echo json_encode(array("error"=>"true","message"=>"successful!"));
  }
  else
  {
 echo json_encode(array("error"=>"false","message"=>"failed!"));
  
  }

 }else if($condition=="updatestatus"){
 $Query="UPDATE smartservice_services SET status='".$status."' WHERE id='".$id."'";
  $result=mysqli_query($con,$Query);
 
  if($result){
   echo json_encode(array("error"=>"true","message"=>"success"));
  }
  else
  {
 echo json_encode(array("error"=>"false","message"=>"updated failed!"));
  
  }
 
}else if($condition=="updaterating"){
 $Query="UPDATE smartservice_services SET rating='".$rating."',feedback='".$feedback."' WHERE id='".$id."'";
  $result=mysqli_query($con,$Query);
 
  if($result){
   echo json_encode(array("error"=>"true","message"=>"success"));
  }
  else
  {
 echo json_encode(array("error"=>"false","message"=>"updated failed!"));
  
  }
 
}
else if($condition=="servicestype"){


data(mysqli_query($con,"SELECT * FROM smartservice_User WHERE type='".$type."' and city like '%$city%'"));
    
}

else if($condition=="serviceshistory"){
$sql="SELECT * FROM smartservice_services WHERE wemail='".$wemail."'ORDER BY `smartservice_services`.`id` DESC";
$result=mysqli_query($con,$sql);
    $user=array();
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
	            $user[] = $row;
                }
echo json_encode(array("error"=>"false","message"=>"Success","user"=>$user));
  }else{
      echo json_encode(array("error"=>"false","message"=>"No data","user"=>$user));
  }


    
}else if($condition=="userhistory"){
$sql="SELECT * FROM smartservice_services WHERE uemail='".$uemail."'ORDER BY `smartservice_services`.`id` DESC";
$result=mysqli_query($con,$sql);
    $user=array();
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
	            $user[] = $row;
                }
echo json_encode(array("error"=>"false","message"=>"Success","user"=>$user));
  }else{
      echo json_encode(array("error"=>"false","message"=>"No data","user"=>$user));
  }


    
}
else if($condition=="deletetable"){
$sql="DELETE FROM eventplan_signup WHERE id='$id'";
 $result=mysqli_query($con,$sql);
  if($result){
   
      $result=mysqli_query($con,$sql);
      echo json_encode(array("error"=>"true","message"=>"Successfully Deleted"));
  }
  else
  {
        echo json_encode(array("error"=>"false","message"=>"Failed to Delete"));
  }
}
}