<?php
$host = "localhost";
$user = "u711879936_sss";
$pass = "android";
$dbname = "u711879936_sss";

$con = mysqli_connect($host, $user, $pass,$dbname);  

if(!$con){  
  die('Could not connect: '.mysqli_connect_error());  
}else{
  
    
    function data($query) {
        
    $user=array();
   if(mysqli_num_rows($query)>0){
    while($row=mysqli_fetch_assoc($query)){
	            $user[] = $row;
                }
      echo json_encode(array("error"=>"false","message"=>"Success","user"=>$user));
     }else{
      echo json_encode(array("error"=>"false","message"=>"No data","user"=>$user));
  }  
    }
    
      $id=$_POST['id'];
      $name=$_POST['name'];
      $email=$_POST['email'];
      $password=$_POST['password'];
      $mobile=$_POST['mobile'];
      $type=$_POST['type'];
      $address=$_POST['address'];
      $loc=$_POST['loc'];
      $city=$_POST['city'];
      $condition=$_POST['condition'];
      
      
if($condition=="register"){

  $checkUser="SELECT * from smartservice_User WHERE email='$email'";
  $checkQuery=mysqli_query($con,$checkUser);

  if(mysqli_num_rows($checkQuery)>0){

   echo json_encode(array("error"=>"true","message"=>"User already exist!"));
  }
  else
  {
     $insertQuery="INSERT INTO smartservice_User ( name,
    email,
    password,
    mobile,
    type,
    address,
    loc,
    city) VALUE( '$name','$email','$password','$mobile','$type','$address','$loc','$city')";
  $result=mysqli_query($con,$insertQuery);
  if($result){
   echo json_encode(array("error"=>"true","message"=>"successful!"));
  }
  else
  {
 echo json_encode(array("error"=>"false","message"=>"failed!"));
  
  }

  }
}else if($condition=="login"){
$sql=" SELECT * FROM  smartservice_User where email='".$email."' and password='".$password."'";
$result=mysqli_query($con,$sql);

if(mysqli_num_rows($result)>0){
while($row=mysqli_fetch_assoc($result)){
	            $user = $row;
}
echo json_encode(array("error"=>"false","message"=>"Login Success","user"=>$user));

mysqli_close($con);
  }


 }else if($condition=="update"){
 $Query="UPDATE smartservice_User SET name='".$name."',password='".$password."',mobile='".$mobile."',address='".$address."',city='".$city."' WHERE id='".$id."'";
  $result=mysqli_query($con,$Query);
 
  if($result){
   echo json_encode(array("error"=>"true","message"=>"success"));
  }
  else
  {
 echo json_encode(array("error"=>"false","message"=>"updated failed!"));
  
  }
 
}
else if($condition=="servicestype"){


data(mysqli_query($con,"SELECT * FROM smartservice_User WHERE type='".$type."'and city='".$city."'"));
    
}

else if($condition=="adminuserstatus"){
$sql="SELECT * FROM eventplan_signup WHERE type='Planner' and city like '$city' and  status='$status'ORDER BY `eventplan_signup`.`id` DESC";
$result=mysqli_query($con,$sql);
    $user=array();
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
	            $user[] = $row;
                }
echo json_encode(array("error"=>"false","message"=>"Success","user"=>$user));
  }else{
      echo json_encode(array("error"=>"false","message"=>"No data","user"=>$user));
  }


    
}else if($condition=="userdonorview"){
$sql="SELECT * FROM blooddonor_signup WHERE type='$type' and city like '$city' and  status='$status' and Blood='$Blood' ORDER BY `blooddonor_signup`.`id` DESC";
$result=mysqli_query($con,$sql);
    $user=array();
if(mysqli_num_rows($result)>0){
    while($row=mysqli_fetch_assoc($result)){
	            $user[] = $row;
                }
echo json_encode(array("error"=>"false","message"=>"Success","user"=>$user));
  }else{
      echo json_encode(array("error"=>"false","message"=>"No data","user"=>$user));
  }


    
}
else if($condition=="deletetable"){
$sql="DELETE FROM eventplan_signup WHERE id='$id'";
 $result=mysqli_query($con,$sql);
  if($result){
   
      $result=mysqli_query($con,$sql);
      echo json_encode(array("error"=>"true","message"=>"Successfully Deleted"));
  }
  else
  {
        echo json_encode(array("error"=>"false","message"=>"Failed to Delete"));
  }
}
}